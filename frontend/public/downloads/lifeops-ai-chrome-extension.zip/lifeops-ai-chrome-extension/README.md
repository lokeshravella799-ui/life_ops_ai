# 🚀 LifeOps AI — Browser Agent (Chrome Extension & Local Agent)
**Version: 1.0.0**

Autonomous Multi-Agent Browser Companion powered by high-speed Groq Inference. Brings page summarization, selection explanations, on-demand vision understanding, and PDF analysis directly into your browser.

---

## 🔒 Privacy & Security Notice

> **The Chrome extension does not contain your Groq API key.**
> All AI inference requests are processed exclusively through your own local LifeOps AI agent running on `http://127.0.0.1:8765`. 
> Your API key remains in `server/.env` on your machine and is **never** transmitted to the browser, extension scripts, or third-party web pages. Keep your API key private.

---

## 📦 What's Inside This Package

```
lifeops-ai-chrome-extension/
├── setup.bat              # One-click Windows setup wizard (creates isolated .venv)
├── start.bat              # Deterministic server launcher (pins to .venv python)
├── start_server.bat       # Convenience server launcher
├── requirements.txt       # Python dependencies list
├── .env.example           # Environment template
├── scripts/
│   └── check_environment.py # Diagnostic & health verification script
├── extension/             # Chrome Extension (Manifest V3)
│   ├── manifest.json      # Extension manifest and permissions
│   ├── background.js      # Service worker & tab capture
│   ├── content.js         # Noise-free DOM text extractor
│   ├── popup.html / .js   # Quick action toolbar popup
│   ├── sidepanel.html/.js # Dockable side companion
│   ├── styles.css         # Modern obsidian/violet design system
│   └── icons/             # App icons (16, 32, 48, 128px)
├── server/                # Localhost Python Companion Server
│   ├── main.py            # FastAPI REST application
│   ├── ai_service.py      # Qwen 3.6 27B chat & text intelligence
│   ├── screen_service.py  # Vision AI visual layout & OCR engine
│   ├── pdf_service.py     # Multi-section structured PDF summarizer
│   ├── config.py          # Port 8765 & model configuration
│   ├── requirements.txt   # FastAPI, Uvicorn, Groq, PyPDF dependencies
│   └── .env.example       # Sample environment template
├── README.md              # Documentation & guide
└── LICENSE                # MIT License
```

---

## ⚡ Quick 3-Minute Setup (Windows)

### Step 1: Run Setup
Double-click `setup.bat` (or `start.bat` which automatically configures setup if missing).
This will verify Python 3.10+, create an isolated virtual environment in `server/.venv`, install requirements, create `server/.env`, and run pre-flight diagnostics.

### Step 2: Configure Your Free Groq API Key
1. Open `server/.env` in Notepad or any text editor.
2. Replace `your_groq_api_key_here` with your key from [Groq Console](https://console.groq.com/keys):
   ```env
   GROQ_API_KEY=your_actual_api_key_here
   ```
3. Save the file.

### Step 3: Start the Local Server
Double-click `start.bat` or `start_server.bat`.
You will see:
```
==================================================
   Starting LifeOps AI Server on http://127.0.0.1:8765
   Interpreter: server\.venv\Scripts\python.exe
==================================================
```
Keep this terminal window open while browsing.

### Step 4: Load Extension in Google Chrome
1. Open Google Chrome and go to `chrome://extensions/`.
2. Turn **ON** the **Developer mode** toggle in the top-right corner.
3. Click the **Load unpacked** button in the top-left corner.
4. Select the `extension` folder inside this extracted package.
5. Pin **LifeOps AI** to your Chrome toolbar.

---

## 🌟 Features & Usage

| Feature | How to Use |
|---|---|
| **📄 Page Summary** | Click extension icon → Click **Analyze Page** or **Page Summary** |
| **🔍 Selection Intelligence** | Highlight text on any page → Right click → *"Ask LifeOps AI about..."* |
| **📸 See My Screen** | Click **See My Screen** to analyze visual layouts, charts, or errors with Vision AI |
| **📑 Summarize PDF** | Open any PDF or click **Summarize PDF** to upload and receive an executive summary |
| **🪟 Side Companion** | Click the side panel dock icon (top-right of popup) for continuous chat while browsing |

---

## 🛠️ Diagnostics & Troubleshooting

- **Diagnose Environment**:
  Run: `server\.venv\Scripts\python.exe scripts\check_environment.py` to inspect Python version, pip location, dependencies, configuration, and port status.
- **Status shows OFFLINE?**
  Make sure `start.bat` is running. Test by visiting `http://127.0.0.1:8765/health` in your browser.
- **Python not recognized?**
  Install Python from [python.org](https://www.python.org/) and make sure to check *"Add Python to PATH"* in the installer.
