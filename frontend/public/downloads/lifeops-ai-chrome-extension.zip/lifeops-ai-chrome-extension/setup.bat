@echo off
title LifeOps AI - Local Agent Setup Wizard
color 0B

echo ================================================================
echo           LIFEOPS AI LOCAL AGENT - SETUP WIZARD (v1.0.0)         
echo ================================================================
echo.

echo [1/4] Checking Python environment...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo [ERROR] Python 3 is not installed or not in your PATH.
    echo Please install Python 3.10+ from https://www.python.org/
    echo (Make sure to check "Add Python to PATH" during installation)
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('python --version') do echo Found: %%i

echo.
echo [2/4] Setting up Python virtual environment in server\.venv...
cd /d "%~dp0server"
if not exist ".venv" (
    python -m venv .venv
    echo Virtual environment created successfully.
) else (
    echo Virtual environment already exists.
)

echo.
echo [3/4] Installing dependencies from requirements.txt...
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt
if %errorlevel% neq 0 (
    color 0C
    echo [ERROR] Dependency installation failed. Please check internet connection.
    pause
    exit /b 1
)

echo.
echo [4/4] Configuring environment settings...
if not exist ".env" (
    copy .env.example .env >nul
    echo Created server\.env from .env.example.
    echo.
    echo ****************************************************************
    echo [ACTION REQUIRED]
    echo 1. Open "server\.env" in Notepad.
    echo 2. Paste your free Groq API key (from https://console.groq.com/keys).
    echo 3. Save the file.
    echo ****************************************************************
) else (
    echo server\.env already exists.
)

echo.
echo ================================================================
echo             SETUP COMPLETE! YOU ARE READY TO RUN                
echo ================================================================
echo 1. Double-click "start_server.bat" to run your local AI agent.
echo 2. Open Google Chrome, go to chrome://extensions/
echo 3. Turn on "Developer mode" (top-right).
echo 4. Click "Load unpacked" and select the "extension" folder.
echo ================================================================
echo.
pause
