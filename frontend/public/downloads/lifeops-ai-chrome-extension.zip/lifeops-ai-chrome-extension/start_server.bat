@echo off
title LifeOps AI - Local Companion Server
color 0A

echo ================================================================
echo       LIFEOPS AI LOCAL AGENT - COMPANION SERVER (v1.0.0)        
echo ================================================================
echo.

cd /d "%~dp0server"

if not exist ".env" (
    color 0E
    echo [WARNING] server\.env not found! Running setup first...
    echo.
    cd /d "%~dp0"
    call setup.bat
    cd /d "%~dp0server"
)

if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
)

echo ================================================================
echo    Server starting on: http://127.0.0.1:8765
echo    Status: ONLINE when Uvicorn startup completes
echo    Press CTRL+C anytime to stop
echo ================================================================
echo.

python main.py
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo [ERROR] Server stopped with an error code.
    echo Please make sure your GROQ_API_KEY in server\.env is valid.
    pause
)
